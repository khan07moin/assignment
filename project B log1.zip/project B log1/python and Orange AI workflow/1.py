import pandas as pd
from sklearn.model_selection import cross_validate
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

# Load Dataset
df = pd.read_csv("diabetes_dataset.csv")

# Features and Target
X = df.iloc[:, :-1]
y = df.iloc[:, -1]

# Models
models = {
    "kNN": KNeighborsClassifier(),
    "Neural Network": MLPClassifier(max_iter=1000),
    "Random Forest": RandomForestClassifier(),
    "SVM": SVC(probability=True),
    "Tree": DecisionTreeClassifier()
}

# Result List
results = []

# Train and Evaluate Models
for name, model in models.items():

    pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="mean")),
        ("scaler", StandardScaler()),
        ("model", model)
    ])

    scores = cross_validate(
        pipeline,
        X,
        y,
        cv=20,
        scoring=[
            'accuracy',
            'precision',
            'recall',
            'f1',
            'roc_auc'
        ]
    )

    results.append({
        "Model": name,
        "AUC": round(scores['test_roc_auc'].mean(), 3),
        "CA": round(scores['test_accuracy'].mean(), 3),
        "F1": round(scores['test_f1'].mean(), 3),
        "Precision": round(scores['test_precision'].mean(), 3),
        "Recall": round(scores['test_recall'].mean(), 3)
    })

# Final Table
result_df = pd.DataFrame(results)

print("\nEvaluation Results Table\n")
print(result_df)
diabetes_dataset(2).csv
df = pd.read_csv("diabetes_dataset(2).csv")
import pandas as pd

df = pd.read_csv("diabetes_dataset(2).csv")

print("Dataset loaded successfully")
print(df.head())
print(df.shape)
print(df.columns)
